# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'e9d39a17af5f85d99d7a6ca1155eb64953986e2308eb5d72f5beef8f167e9e156085d84ca3c1420bc1537b968cffa664be1904ff43644c33f16f866c5f6f52f3'
